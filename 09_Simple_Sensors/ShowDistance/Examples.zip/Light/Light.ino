void setup() {
  // put your setup code here, to run once:
}

void loop()
{
  Value = analgoRead(A0);

  if( Value > 200 )
    digitalWrite(13, HIGH);
  else
    digitalWrite(13, LOW);   
}
